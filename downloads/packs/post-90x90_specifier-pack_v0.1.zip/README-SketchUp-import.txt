How to use these models in SketchUp
====================================
SketchUp Pro / desktop: File > Import > choose "COLLADA File (*.dae)" > Options: units = Millimetres > Import.
SketchUp for Web (free): Open > Import > select the .dae file.
Each standard length is a separate named component; the colour is a named material.
Origin: bottom-left corner of the profile end. Scale: 1:1, millimetres.

These are simplified envelope models (outer dimensions exact; hollow cores and grooves not shown),
version 0.1, generated 2026-11-06 from the supplier price list. Check the spec sheet before construction.

Utilisation dans SketchUp
=========================
SketchUp Pro : Fichier > Importer > « Fichier COLLADA (*.dae) » > Options : unités = millimètres.
SketchUp pour le Web : Ouvrir > Importer > fichier .dae.
Modèles simplifiés (dimensions extérieures exactes; alvéoles et rainures non représentées).
